// ==UserScript==
// @name         DLR-V4 | Bypass for Work.ink, AdMaven, LootLabs & Shitvertise
// @namespace    dlr.kys.gay
// @version      4.3
// @description  Bypass AdLinks and various executors.
// @run-at       document-body
// @license      MIT
// @homepageURL  https://dlr.kys.gay/bio/woozie
// @supportURL   https://dlr.kys.gay/ds
// @icon         https://dlr.kys.gay/DLR.jpg
// @match        https://dlr.kys.gay/

// @match        *://linkvertis*.com/*
// @match        *://cety.app/*
// @match        *://cuty.io/*
// @match        *://bstlar.com/*
// @match        *://mboost.me/*
// @match        *://work.ink/*
// @match        *://workink.net/*
// @match        *://r.work.ink/*
// @match        *://keyrblx.com/getkey/*
// @match        *://loot-link.com/s?*
// @match        *://loot-links.com/s?*
// @match        *://ebaticalfel.com/s?*
// @match        *://onepiecered.co/s?*
// @match        *://lootlink.org/s?*
// @match        *://lootlinks.co/s?*
// @match        *://lootdest.info/s?*
// @match        *://lootdest.org/s?*
// @match        *://lootdest.com/s?*
// @match        *://links-loot.com/s?*
// @match        *://linksloot.net/s?*
// @match        *://mega-guy.com/s?*
// @match        *://ofpacksmega.com/s?*
// @match        *://depravityweb.co/s?*
// @match        *://secretpack-links.com/s?*
// @match        *://secret-links.com/s?*
// @match        *://tavernleaks.com/s?*
// @match        *://free-leaks.com/s?*
// @match        *://hotstars-leaks.com/s?*
// @match        *://thepremium.online/s?*
// @match        *://admiregirls-byme.com/s?*
// @match        *://all-fans.online/s?*
// @match        *://pnp-drops.me/s?*
// @match        *://megadropz.com/s?*
// @match        *://goldmega.online/s?*
// @match        *://badgirlsdrop.com/s?*
// @match        *://rareofhub.com/s?*
// @match        *://only-fun.xyz/s?*
// @match        *://megadumpz.com/s?*
// @match        *://leakutopia.site/s?*
// @match        *://xprmpacks.com/s?*
// @match        *://onlymega.co/s?*
// @match        *://tomxcontent.com/s?*
// @match        *://newsociety0.co/s?*
// @match        *://cemendemons.com/s?*
// @match        *://fansmega.com/s?*
// @match        *://premiumstashdrop.com/s?*
// @match        *://paster.so/*
// @match        *://*.*/s?*
// @exclude      https://tria.ge/*
// @connect      https://dlr.kys.gay/bypass/
// @connect      https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css
// @connect      https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js
// @grant        GM_setClipboard
// @grant        GM_xmlhttpRequest
// @grant        GM_getResourceText
// @grant        GM_addStyle
// @resource     NOTYF_CSS https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css
// @require      https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js
// @author       iWoozy_real
// @description  Bypass ad links with DLR's userscript
// @downloadURL https://update.greasyfork.org/scripts/499257/DLR-V4%20%7C%20Bypass%20for%20Workink%2C%20AdMaven%2C%20LootLabs%20%20Shitvertise.user.js
// @updateURL https://update.greasyfork.org/scripts/499257/DLR-V4%20%7C%20Bypass%20for%20Workink%2C%20AdMaven%2C%20LootLabs%20%20Shitvertise.meta.js
// ==/UserScript==
(function() {
    'use strict';
    const sleepTime=12 // Seconds

    // Utility Functions
    const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

    function createNotyf() {
        GM_addStyle(GM_getResourceText("NOTYF_CSS"));
        return new Notyf({
            duration: 5000,
            position: { x: 'right', y: 'top' }
        });
    }

    const notyf = createNotyf();
    const notify = (type, text) => {
        try {
            notyf[type](text);
        } catch {
            console.log(text);
        }
    };

    // Redirect Handling
    if (document.title.includes('Just a moment...') || document.title.includes('Just a second...')) {
        return;
    }

    if (location.href.includes('x_dlr_redirect_to=')) {
        const urlParams = new URLSearchParams(location.search);
        const redirectTo = urlParams.get('x_dlr_redirect_to');
        if (redirectTo) {
            window.location.replace(decodeURIComponent(redirectTo));
        }
        return;
    }

    // Ad Spoofing Function
    function adSpoof(link, referrer) {
        const prefix = referrer.includes('?') ? '&' : '?';
        const linkElement = document.createElement('a');
        linkElement.href = `https://${referrer}${prefix}x_dlr_redirect_to=${encodeURIComponent(link)}`;
        linkElement.textContent = 'Lets bypass this shit, DYNAMIC LINK RESOLVER ON TOP!';
        document.body.appendChild(linkElement);
        linkElement.click();
    }

    // Turnstile Response Handling
    async function getTurnstileResponse() {
        notify('success', 'Please solve the captcha');
        const intervalId = setInterval(() => notify('success', 'Please solve the captcha'), 5000);
        let response;

        while (!(response = turnstile.getResponse())) {
            await wait(1000);
        }

        clearInterval(intervalId);
        return response;
    }

    // Linkvertis Bypass Function
    async function lvBotBypass() {
        const checkInterval = setInterval(() => {
            if (document.body.innerHTML.includes(" More from Linkverti") && document.body.innerHTML.includes(" Views ")) {
                clearInterval(checkInterval);
                try {
                    const primaryButton = document.querySelector('.lv-lib-button--primary');
                    if (primaryButton) {
                        primaryButton.click();
                    } else {
                        throw new Error("Primary button not found");
                    }
                } catch (error) {
                    notify('error', '[BOTMODE]: Failed to click the primary button');
                }

                setTimeout(() => {
                    const secondaryButtonInterval = setInterval(async () => {
                        const secondaryButton = document.querySelector('.lv-lib-button--secondary');
                        if (secondaryButton && !document.body.innerHTML.includes('Get Access in ')) {
                            secondaryButton.textContent = 'Unlocked by https://dlr.kys.gay';
                            Object.assign(secondaryButton.style, {
                                position: 'fixed',
                                top: '0',
                                left: '0',
                                width: '100%',
                                height: '100%',
                                zIndex: '9999',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '1.5em',
                                backgroundColor: '#28a745',
                                color: '#fff',
                                border: 'none',
                                textAlign: 'center'
                            });

                            const additionalText = document.createElement('div');
                            additionalText.textContent = "DLR's Bypasser ON TOP";
                            Object.assign(additionalText.style, {
                                marginTop: '20px',
                                fontSize: '1em',
                                color: '#fff'
                            });

                            secondaryButton.appendChild(additionalText);
                            clearInterval(secondaryButtonInterval);
                            await wait(500);
                            secondaryButton.click();
                            setTimeout(() => window.location.href = 'https://dlr.kys.gay', 5000);
                        }
                        if (!document.body.innerHTML.includes('Get Access in 00:')) {
                            fetch(`https://dlr.kys.gay/api/free/bypass?url=${encodeURIComponent(location.href)}`)
                                .then(response => response.json())
                                .then(data => location.href = data.result)
                                .catch(error => console.error('Error:', error));
                        }
                    }, 1000);
                }, 2000);
            }
        }, 100);
    }

    // Set Style Function
    async function setStyle() {
      try{
        const style = document.createElement('style');
        style.textContent = `
            body {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                background-size: cover;
                background-position: center;
                background-color: gray;
                color: black;
                font-family: Arial, sans-serif;
                font-size: 24px;
                margin: 0;
            }
        `;
        document.head.appendChild(style);
      }catch{}
    }

    // Client-Side Bypass Function
    async function ClientSide() {
        if (location.href.includes("linkvertis") || location.href.includes("paster.so") || location.href.includes("/s?") || location.href.includes("work.ink") || location.href.includes("workink")) {
            await setStyle();
            const endpoint = 'https://dlr.kys.gay/';
            let info = `| Waiting ${sleepTime} seconds to avoid bypass detections |`;
            setInterval(()=>{
              document.body.innerHTML = `<div>${info}</div>`;
            },1000)
            await wait(sleepTime*1000);
            info="Client-Side Bypassing, please wait..."
            const r = new URL(window.location.href).searchParams.get("r");
            if (r && location.href.includes("linkvertis")) {
                await lvBotBypass();
                return;
            }

            const apiUrl = `${endpoint}api/free/bypass`;
            const urlParam = encodeURIComponent(window.location.href);

            for (let retryCount = 0; retryCount < 100; retryCount++) {
                try {
                    const response = await fetch(`${apiUrl}?url=${urlParam}`);
                    if (response.ok) {
                        const data = await response.json();
                        if (data.success && data.result.startsWith("http")) {
                            info = `Client-side bypass success! Please wait while we redirect you... (result : ${data.result})`;
                            await wait(2000);
                            location.href = data.result;
                            await wait(9e9);
                            return;
                        }
                        if (data.result.includes("bypass fail")) {
                            info = `Bypass fail! Error bypassing your link: ${data.result}`;
                            await wait(9e9);
                            return;
                        }
                        info = "Bypassed! Result copied to clipboard!";
                        GM_setClipboard(data.result);
                        await wait(9e9);
                        return;
                    }
                    info = response.status === 500
                        ? "The API is being rate-limited by Cloudflare. Please use our Discord bot to bypass this link."
                        : `Error while getting the API result, error code: ${response.status}. Retrying... (${retryCount}/100)`;
                } catch {
                    console.error('Error while fetching data.');
                }
            }

            info = "Exceeded maximum retries. Unable to fetch data. Please use our Discord bot to bypass this link.";
            await wait(9e9);
        }
    }

    // Bypass Function
    async function bypass() {
        if (location.href.includes("https://dlr.kys.gay")) {
            const tobyp = new URL(window.location.href).searchParams.get('url');
            if (!tobyp) return;

            await wait(2000);
            document.getElementById("urlInput").value = tobyp;
            await getTurnstileResponse();
            await wait(1000);
            document.getElementById("bypassBtn").click();

            async function getBypass() {
                const textarea = document.getElementById("resultTextbox");
                if (textarea.value) {
                    try {
                        const resultUrl = new URL(textarea.value);
                        const oldUrl= new URL(document.getElementById("urlInput").value)
                        notify('success', "Bypassed! Please wait while we redirect you...");
                        await wait(4000);
                        adSpoof(textarea.value, oldUrl.hostname);
                    } catch {
                        if (textarea.value.includes("bypass fail!")) {
                            notify('error', "Error bypassing. Result: " + textarea.value);
                        } else {
                            notify('success', "Bypassed! Result copied to clipboard!");
                            GM_setClipboard(textarea.value);
                        }
                    }
                } else {
                    setTimeout(getBypass, 1000);
                }
            }
            getBypass();
        } else {
            await ClientSide();
            notify('error', "Client-side bypass failed! Redirecting to our bypass website...");
            const linkElement = document.createElement('a');
            linkElement.href = `https://dlr.kys.gay?url=${encodeURIComponent(location.href)}`;
            linkElement.textContent = 'Bypass result';
            document.body.appendChild(linkElement);
            linkElement.click();
        }
    }
    notify('success', "Dynamic Link Resolver Userscript LOADED!");
    bypass();
})();
